# Abnahme des Entwicklungsservers

**Server:** ____________________  **Standort:** ____________________
**Eingerichtet von:** ____________________  **Datum:** ____________

Bitte ausgefüllt zurückgeben — sie wandert als Nachweis in den Projektordner.

| # | Punkt | Wie geprüft | ✔ |
|---|---|---|---|
| 1 | **Standort ist Falkenstein, Nürnberg oder Helsinki** | Hetzner-Konsole | ☐ |
| 2 | **Anmeldung als root nicht mehr möglich** | `ssh root@<ip>` wird abgewiesen | ☐ |
| 3 | **Passwortanmeldung aus** | `ssh -o PubkeyAuthentication=no cruizy@<ip>` wird abgewiesen | ☐ |
| 4 | **Firewall zu außer SSH** | `sudo ufw status verbose` | ☐ |
| 5 | **Kein Anschluss offen nach außen** | `sudo ss -ltnp \| grep -v 127.0.0.1` zeigt nur SSH | ☐ |
| 6 | **Alle Dienste laufen** | `docker compose ps` — keiner „exited" | ☐ |
| 7 | **Postgres-Fassung notiert** | `docker compose exec -T db psql -U postgres -c "SHOW server_version"` → ________ | ☐ |
| 8 | **Rauchtest bestanden** | 04-Skript meldete „Rolle anon kann geometry auflösen" | ☐ |
| 9 | **Rauchtest auch über REST** | 04-Skript meldete eine Antwort der REST-Schnittstelle | ☐ |
| 10 | **Probe-Rückspielung bestanden** | 05-Skript meldete „Die Sicherung ist nachweislich zurückspielbar" | ☐ |

**Zusätzlich, sobald echte Daten daraufsollen (ANLEITUNG.md, Abschnitt 12):**

| # | Punkt | ✔ |
|---|---|---|
| 11 | Auftragsverarbeitungsvertrag mit Hetzner abgeschlossen | ☐ |
| 12 | Unterauftragsverarbeiterliste zu den Unterlagen genommen | ☐ |
| 13 | Zweite, verschlüsselte Sicherungskopie an einem anderen Ort | ☐ |
| 14 | Überwachung eingerichtet | ☐ |

## Was aufgefallen ist

Abweichungen, Fehlermeldungen, Dinge die anders liefen als beschrieben:

```



```

## Werte zum Nachtragen

| | |
|---|---|
| Server-IP | |
| Kerne / Arbeitsspeicher / Platte | |
| Postgres-Fassung | |
| Supabase-Feststand (aus `/opt/cruizy/HERKUNFT.txt`) | |
| Sicherung läuft täglich um | |
