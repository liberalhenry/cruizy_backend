#!/usr/bin/env bash
# sichern.sh · Tägliche Sicherung der Datenbank und der Konfiguration.
# Wird von systemd aufgerufen, läuft aber auch von Hand.
set -euo pipefail

CRUIZY_BASIS="${CRUIZY_BASIS:-/opt/cruizy}"
CRUIZY_STACK="${CRUIZY_STACK:-${CRUIZY_BASIS}/supabase}"
ZIEL="${CRUIZY_SICHERUNG:-${CRUIZY_BASIS}/sicherungen}"
BEHALTEN_TAGE="${CRUIZY_BEHALTEN:-14}"
STEMPEL="$(date +%Y-%m-%d_%H%M%S)"

mkdir -p "$ZIEL"
cd "$CRUIZY_STACK"

ABBRUCH() { echo "FEHLER: $*" >&2; exit 1; }

# 1 · Datenbank. pg_dumpall erfasst auch Rollen und deren Suchpfade — genau die,
#     die PostGIS über die REST-Schnittstelle tragbar machen.
DATEI="${ZIEL}/db_${STEMPEL}.sql.gz"
docker compose exec -T db pg_dumpall -U postgres --clean --if-exists \
  | gzip -9 > "${DATEI}.teil" || ABBRUCH "pg_dumpall fehlgeschlagen"
mv "${DATEI}.teil" "$DATEI"
chmod 600 "$DATEI"

# 2 · Die Sicherung muss lesbar sein, sonst ist sie eine Vermutung.
gzip -t "$DATEI" || ABBRUCH "Die erzeugte Datei ist kein gültiges gzip"
GROESSE=$(stat -c%s "$DATEI")
(( GROESSE > 10240 )) || ABBRUCH "Sicherung ist nur ${GROESSE} Byte groß — das kann nicht stimmen"
zcat "$DATEI" | head -50 | grep -q 'PostgreSQL database' || ABBRUCH "Kein Postgres-Abzug im Inhalt gefunden"

# 3 · Konfiguration und Herkunft. .env enthält Geheimnisse -> 600.
KONF="${ZIEL}/konfig_${STEMPEL}.tar.gz"
tar -czf "$KONF" -C "$CRUIZY_BASIS" \
    --exclude='sicherungen' --exclude='volumes/db/data' --exclude='volumes/storage' \
    HERKUNFT.txt 2>/dev/null || true
tar -rzf "$KONF" -C "$CRUIZY_STACK" .env docker-compose.override.yml 2>/dev/null \
  || tar -czf "$KONF" -C "$CRUIZY_STACK" .env docker-compose.override.yml
chmod 600 "$KONF"

# 4 · Objektspeicher (hochgeladene Dateien), falls vorhanden.
if [[ -d "${CRUIZY_STACK}/volumes/storage" ]]; then
  DATEIEN="${ZIEL}/dateien_${STEMPEL}.tar.gz"
  tar -czf "$DATEIEN" -C "${CRUIZY_STACK}/volumes" storage
  chmod 600 "$DATEIEN"
fi

# 5 · Altes wegräumen.
find "$ZIEL" -maxdepth 1 -type f -mtime "+${BEHALTEN_TAGE}" -name '*_*' -delete

# 6 · Ergebnis melden.
echo "$(date -Is) | ok | $(basename "$DATEI") | $(numfmt --to=iec "$GROESSE")" >> "${ZIEL}/protokoll.txt"
echo "Sicherung fertig: ${DATEI} ($(numfmt --to=iec "$GROESSE"))"
echo "Im Ziel liegen jetzt $(find "$ZIEL" -maxdepth 1 -name 'db_*.sql.gz' | wc -l) Datenbankabzüge."
