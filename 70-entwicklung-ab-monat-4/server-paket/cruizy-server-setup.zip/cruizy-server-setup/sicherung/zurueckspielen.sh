#!/usr/bin/env bash
# zurueckspielen.sh · Spielt eine Sicherung zurück.
#
# ⚠ Dieses Skript ÜBERSCHREIBT die laufende Datenbank. Es fragt zweimal nach.
#
# Aufruf:  bash sicherung/zurueckspielen.sh /opt/cruizy/sicherungen/db_2026-09-28_030000.sql.gz
#
# Zum ÜBEN ohne Gefahr:  CRUIZY_PROBE=1 bash sicherung/zurueckspielen.sh <datei>
# Dann wird in eine Wegwerf-Datenbank zurückgespielt und danach nur berichtet,
# ob es funktioniert hätte. Genau das verlangt Art. 32 DSGVO: eine Wiederherstellung,
# die einmal wirklich durchgespielt wurde.
set -euo pipefail

CRUIZY_BASIS="${CRUIZY_BASIS:-/opt/cruizy}"
CRUIZY_STACK="${CRUIZY_STACK:-${CRUIZY_BASIS}/supabase}"
DATEI="${1:-}"
PROBE="${CRUIZY_PROBE:-0}"

[[ -n "$DATEI" ]] || { echo "Aufruf: $0 <sicherungsdatei.sql.gz>"; exit 2; }
[[ -r "$DATEI" ]] || { echo "Datei nicht lesbar: $DATEI"; exit 2; }
gzip -t "$DATEI" || { echo "Datei ist kein gültiges gzip: $DATEI"; exit 2; }

cd "$CRUIZY_STACK"

if [[ "$PROBE" == "1" ]]; then
  PROBEDB="cruizy_probe_$(date +%s)"
  echo "▸ Probelauf — die laufende Datenbank wird NICHT angefasst."
  echo "  Zieldatenbank: ${PROBEDB}"
  docker compose exec -T db psql -U postgres -c "CREATE DATABASE ${PROBEDB}" >/dev/null
  # pg_dumpall enthält \connect-Anweisungen; für den Probelauf interessiert nur,
  # ob sich der Abzug überhaupt einlesen lässt und wie viele Tabellen entstehen.
  set +e
  zcat "$DATEI" | docker compose exec -T db psql -U postgres -d "${PROBEDB}" -v ON_ERROR_STOP=0 >/dev/null 2>/tmp/probe.err
  set -e
  TABELLEN="$(docker compose exec -T db psql -U postgres -d "${PROBEDB}" -tAc \
    "SELECT count(*) FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')" \
    2>/dev/null | tr -d '\r')"
  FEHLER="$(wc -l < /tmp/probe.err || echo 0)"
  docker compose exec -T db psql -U postgres -c "DROP DATABASE ${PROBEDB}" >/dev/null
  echo "  Ergebnis: ${TABELLEN:-0} Tabelle(n) entstanden, ${FEHLER} Meldung(en) beim Einlesen."
  echo "  Wegwerf-Datenbank wieder entfernt."
  if [[ "${TABELLEN:-0}" -gt 0 ]]; then
    echo "  ✔ Die Sicherung ist zurückspielbar."
    echo "$(date -Is) | probe ok | $(basename "$DATEI") | ${TABELLEN} Tabellen" >> "${CRUIZY_BASIS}/sicherungen/protokoll.txt"
    exit 0
  else
    echo "  ✖ Es sind keine Tabellen entstanden. Die Sicherung taugt nicht."
    head -20 /tmp/probe.err
    exit 1
  fi
fi

echo "⚠ ECHTES ZURÜCKSPIELEN"
echo "  Datei : $DATEI"
echo "  Ziel  : die laufende Datenbank in ${CRUIZY_STACK}"
echo "  Alles, was seit dieser Sicherung entstanden ist, geht verloren."
read -r -p "  Tippe ZURUECKSPIELEN, um fortzufahren: " A1
[[ "$A1" == "ZURUECKSPIELEN" ]] || { echo "Abgebrochen."; exit 1; }
read -r -p "  Wirklich? [j/N] " A2
[[ "$A2" =~ ^[jJyY]$ ]] || { echo "Abgebrochen."; exit 1; }

echo "▸ Sicherheitskopie des jetzigen Standes"
NOTFALL="${CRUIZY_BASIS}/sicherungen/vor-ruecksicherung_$(date +%Y-%m-%d_%H%M%S).sql.gz"
docker compose exec -T db pg_dumpall -U postgres | gzip -9 > "$NOTFALL"
chmod 600 "$NOTFALL"
echo "  Liegt in ${NOTFALL}"

echo "▸ Dienste anhalten, die auf die Datenbank schreiben"
docker compose stop rest auth realtime storage 2>/dev/null || true

echo "▸ Zurückspielen"
zcat "$DATEI" | docker compose exec -T db psql -U postgres -v ON_ERROR_STOP=0

echo "▸ Dienste wieder starten"
docker compose start rest auth realtime storage 2>/dev/null || docker compose up -d

echo "$(date -Is) | zurueckgespielt | $(basename "$DATEI")" >> "${CRUIZY_BASIS}/sicherungen/protokoll.txt"
echo "✔ Fertig. Prüfe die Anwendung, bevor du ${NOTFALL} löschst."
