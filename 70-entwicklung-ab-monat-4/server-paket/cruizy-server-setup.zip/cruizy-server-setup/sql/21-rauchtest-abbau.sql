-- 21-rauchtest-abbau.sql · Räumt die Wegwerf-Teile des Rauchtests weg.
\set ON_ERROR_STOP on
DROP FUNCTION IF EXISTS public.cruizy_rauchtest_umkreis(double precision, double precision, double precision);
DROP TABLE IF EXISTS public.cruizy_rauchtest;
SELECT 'Abbau fertig' AS stand;
