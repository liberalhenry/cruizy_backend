-- 10-postgis.sql · PostGIS so einrichten, dass es auch über die REST-Schnittstelle trägt.
--
-- Hintergrund: In selbst gehosteten Supabase-Installationen ist mehrfach berichtet
-- worden, dass Abfragen mit PostGIS im SQL-Editor laufen, über rpc() aber mit
-- 'type "geometry" does not exist' scheitern (supabase/supabase, Fehlerbericht 27295,
-- abgerufen 28.09.2026). Ursache ist der Suchpfad der Rolle, mit der PostgREST
-- verbindet: Das Schema, in dem die PostGIS-Typen liegen, steht nicht darin.
--
-- Für Cruizy ist das kein Randfall, sondern der Kern: die gesamte Standortarchitektur
-- (Arbeitspaket AP-2, Sitzung S2) rechnet mit geometry über die REST-Schnittstelle.
--
-- Dieses Skript ist mehrfach ausführbar (idempotent) und verschiebt eine bereits
-- vorhandene PostGIS-Installation NICHT. Es liest stattdessen aus, in welchem Schema
-- sie liegt, und richtet den Suchpfad danach aus. Grund: Das Verschieben von PostGIS
-- zwischen Schemata ist fehleranfällig; der Suchpfad ist die verlässlichere Stelle.

\set ON_ERROR_STOP on

-- 1 · Schema für Erweiterungen. In Supabase vorhanden; hier der Vollständigkeit halber.
CREATE SCHEMA IF NOT EXISTS extensions;

-- 2 · PostGIS anlegen, falls es noch gar nicht da ist — dann nach extensions.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'postgis') THEN
    EXECUTE 'CREATE EXTENSION postgis WITH SCHEMA extensions';
    RAISE NOTICE 'PostGIS neu angelegt in Schema extensions';
  ELSE
    RAISE NOTICE 'PostGIS war bereits vorhanden — wird nicht verschoben, siehe Schritt 5';
  END IF;
END
$$;

-- 3 · Weitere Erweiterungen, die die Spezifikation braucht.
DO $$
DECLARE
  e text;
BEGIN
  FOREACH e IN ARRAY ARRAY['pgcrypto','pg_trgm','citext']
  LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_extension WHERE extname = e) THEN
      EXECUTE format('CREATE EXTENSION %I WITH SCHEMA extensions', e);
      RAISE NOTICE 'Erweiterung % angelegt', e;
    END IF;
  END LOOP;
END
$$;

-- 4 · Lesezugriff auf alle Schemata, in denen Erweiterungen liegen.
DO $$
DECLARE
  r text;
  s text;
BEGIN
  FOR s IN
    SELECT DISTINCT n.nspname
      FROM pg_extension e JOIN pg_namespace n ON n.oid = e.extnamespace
     WHERE e.extname IN ('postgis','pgcrypto','pg_trgm','citext')
  LOOP
    FOREACH r IN ARRAY ARRAY['anon','authenticated','service_role','authenticator','postgres']
    LOOP
      IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
        EXECUTE format('GRANT USAGE ON SCHEMA %I TO %I', s, r);
        EXECUTE format('GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA %I TO %I', s, r);
      END IF;
    END LOOP;
    RAISE NOTICE 'Schema % für die vorhandenen Rollen freigegeben', s;
  END LOOP;
END
$$;

-- 5 · Der eigentliche Punkt: Suchpfad aus dem TATSÄCHLICHEN Schema von PostGIS bauen.
DO $$
DECLARE
  postgis_schema text;
  pfad text;
  r text;
BEGIN
  SELECT n.nspname INTO postgis_schema
    FROM pg_extension e JOIN pg_namespace n ON n.oid = e.extnamespace
   WHERE e.extname = 'postgis';

  IF postgis_schema IS NULL THEN
    RAISE EXCEPTION 'PostGIS ist nicht installiert — Abbruch, sonst trägt die Standortarchitektur nicht.';
  END IF;

  IF postgis_schema IN ('public','extensions') THEN
    pfad := 'public, extensions';
  ELSE
    pfad := format('public, %I, extensions', postgis_schema);
  END IF;
  RAISE NOTICE 'PostGIS liegt in %. Suchpfad wird: %', postgis_schema, pfad;

  -- Auch 'postgres' und 'supabase_admin' brauchen den Pfad: Mit diesen Rollen laufen
  -- die Migrationen. Ohne den Pfad scheitert schon ein CREATE TABLE mit einer
  -- geometry-Spalte an 'type "geometry" does not exist' — geprüft am 28.09.2026.
  FOREACH r IN ARRAY ARRAY['anon','authenticated','service_role','authenticator',
                           'postgres','supabase_admin','supabase_storage_admin']
  LOOP
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format('ALTER ROLE %I SET search_path = %s', r, pfad);
      RAISE NOTICE 'Suchpfad gesetzt für %', r;
    ELSE
      RAISE NOTICE 'Rolle % gibt es hier nicht — übersprungen', r;
    END IF;
  END LOOP;

  -- Zusätzlich auf Datenbankebene, damit auch Werkzeuge greifen, die mit einer
  -- hier nicht aufgeführten Rolle verbinden.
  EXECUTE format('ALTER DATABASE %I SET search_path = %s', current_database(), pfad);
  RAISE NOTICE 'Suchpfad auch auf Datenbankebene gesetzt (%)', current_database();
END
$$;

-- 6 · Künftige Funktionen im Schema extensions gleich mit Ausführungsrecht versehen.
DO $$
DECLARE
  r text;
BEGIN
  FOREACH r IN ARRAY ARRAY['anon','authenticated','service_role']
  LOOP
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format(
        'ALTER DEFAULT PRIVILEGES IN SCHEMA extensions GRANT EXECUTE ON FUNCTIONS TO %I', r);
    END IF;
  END LOOP;
END
$$;

-- 7 · Ergebnis zeigen.
SELECT e.extname AS erweiterung,
       n.nspname AS schema,
       e.extversion AS fassung
  FROM pg_extension e
  JOIN pg_namespace n ON n.oid = e.extnamespace
 WHERE e.extname IN ('postgis','pgcrypto','pg_trgm','citext')
 ORDER BY e.extname;

SELECT current_setting('server_version') AS postgres_fassung;
