-- 20-rauchtest-aufbau.sql · Legt eine Wegwerf-Tabelle und -Funktion an, mit denen
-- geprüft wird, ob geometry über die REST-Schnittstelle trägt.
-- Gegenstück: 21-rauchtest-abbau.sql räumt alles wieder weg.
\set ON_ERROR_STOP on

CREATE TABLE IF NOT EXISTS public.cruizy_rauchtest (
  id    integer PRIMARY KEY,
  punkt geometry(Point, 4326) NOT NULL
);

INSERT INTO public.cruizy_rauchtest (id, punkt)
VALUES (1, ST_SetSRID(ST_MakePoint(6.9603, 50.9375), 4326))   -- Köln, Dom
ON CONFLICT (id) DO NOTHING;

-- Entfernungsabfrage, wie die Standortarchitektur sie braucht (AP-2, F60, F70).
CREATE OR REPLACE FUNCTION public.cruizy_rauchtest_umkreis(
  breite double precision,
  laenge double precision,
  meter  double precision
) RETURNS TABLE (ort_id integer, entfernung_m double precision)
LANGUAGE sql STABLE AS $fn$
  SELECT t.id,
         ST_Distance(t.punkt::geography,
                     ST_SetSRID(ST_MakePoint(laenge, breite), 4326)::geography)
    FROM public.cruizy_rauchtest t
   WHERE ST_DWithin(t.punkt::geography,
                    ST_SetSRID(ST_MakePoint(laenge, breite), 4326)::geography,
                    meter);
$fn$;

DO $$
DECLARE r text;
BEGIN
  FOREACH r IN ARRAY ARRAY['anon','authenticated','service_role'] LOOP
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format('GRANT USAGE ON SCHEMA public TO %I', r);
      EXECUTE format('GRANT SELECT ON public.cruizy_rauchtest TO %I', r);
      EXECUTE format('GRANT EXECUTE ON FUNCTION public.cruizy_rauchtest_umkreis TO %I', r);
    END IF;
  END LOOP;
END $$;

SELECT 'Aufbau fertig' AS stand;
