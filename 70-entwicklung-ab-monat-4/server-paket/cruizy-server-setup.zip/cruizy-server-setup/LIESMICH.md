# Cruizy-Serverpaket — fang hier an

**Für den Entwicklungsserver auf einem Hetzner-VPS mit Ubuntu 24.04 LTS.**
Erstellt 28.09.2026 · Aufgabe A-71 · Fassung siehe `FASSUNG.txt`

## In drei Sätzen

Dieses Paket richtet einen frischen Ubuntu-Server so ein, dass darauf ein selbst gehostetes
Supabase mit PostgreSQL und PostGIS läuft — gehärtet, von außen nicht erreichbar, täglich
gesichert und mit einer einmal wirklich durchgespielten Rückspielung.
**Die vollständige Anleitung steht in `ANLEITUNG.md`.** Lies sie, bevor du ein Skript aufrufst.

## Der eine Punkt, bei dem nichts schiefgehen darf

**Der Standort des Servers muss Falkenstein, Nürnberg oder Helsinki sein.**
Ashburn, Hillsboro und Singapur brechen Grundsatzbeschluss G-01 des Projekts.
Begründung in `ANLEITUNG.md`, Abschnitt 2.1.

## Reihenfolge

| | Aufruf | Was |
|---|---|---|
| 1 | `sudo bash skripte/00-vorpruefung.sh` | prüft nur, ändert nichts |
| 2 | `sudo bash skripte/01-grundhaertung.sh` | Nutzer, SSH, Firewall, fail2ban, Swap |
| 3 | `sudo bash skripte/02-docker.sh` | Docker — danach ab- und wieder anmelden |
| 4 | `bash skripte/03-supabase-holen.sh` | Supabase, Geheimnisse, Anschlüsse zunageln |
| 5 | `bash skripte/04-starten-und-postgis.sh` | starten, PostGIS, **Rauchtest** |
| 6 | `sudo bash skripte/05-sicherung-einrichten.sh` | Sicherung + Probe-Rückspielung |
| 7 | `PRUEFLISTE.md` ausfüllen | Abnahme |

Schritte 4 und 5 laufen **ohne** `sudo`.

## Was drin ist

```
LIESMICH.md      diese Datei
ANLEITUNG.md     die vollständige Schritt-für-Schritt-Anleitung
PRUEFLISTE.md    Abnahme, zehn Punkte
FASSUNG.txt      Fassung und Prüfsummen aller Dateien
skripte/         die sechs nummerierten Skripte, lib.sh und bindung.py
sql/             PostGIS-Einrichtung und Rauchtest
sicherung/       sichern.sh und zurueckspielen.sh
vorlagen/        Caddyfile und .env-Zusatz für später
```

## Drei Dinge, die dieses Paket bewusst tut

**Es bindet alle Anschlüsse an 127.0.0.1.** Docker schreibt seine Regeln unterhalb von ufw;
ohne diesen Schritt steht die Datenbank offen im Netz, obwohl die Firewall „alles zu" meldet.
Das Skript liest die echte Compose-Konfiguration aus, statt Dienstnamen zu raten.

**Es prüft PostGIS über den echten Weg.** Für selbst gehostetes Supabase ist bekannt, dass
`geometry` im SQL-Editor läuft und über `rpc()` scheitert. Das trifft die Standortarchitektur
von Cruizy im Kern. Der Rauchtest fängt es ab, bevor darauf gebaut wird.

**Es spielt eine Sicherung einmal wirklich zurück.** In eine Wegwerf-Datenbank, ohne die
laufende anzufassen. Eine Sicherung, die nie zurückgespielt wurde, ist eine Vermutung.

## Was es nicht tut

Keine Produktion. Keine Überwachung. Keine zweite Kopie außer Haus. Kein Zertifikat, solange
keine Unterdomain zeigt. Alles vier steht in `ANLEITUNG.md`, Abschnitt 11, mit Vorschlag.

**Und: auf diesem Server liegen ausschließlich erfundene Daten.** Keine Wartelistenadressen,
keine Interviewaufnahmen. Ab dem ersten echten Menschen gilt Abschnitt 12.
