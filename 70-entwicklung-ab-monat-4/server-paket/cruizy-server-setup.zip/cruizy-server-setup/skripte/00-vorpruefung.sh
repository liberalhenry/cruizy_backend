#!/usr/bin/env bash
# 00 · Vorprüfung — ändert nichts, prüft nur.
# Aufruf:  sudo bash skripte/00-vorpruefung.sh
source "$(dirname "$0")/lib.sh"
braucht_root

MANGEL=0
merke_mangel() { MANGEL=$((MANGEL+1)); }

schritt "Betriebssystem"
if [[ -r /etc/os-release ]]; then
  . /etc/os-release
  echo "     $PRETTY_NAME"
  if [[ "${ID:-}" != "ubuntu" ]]; then
    warnung "Dieses Paket ist für Ubuntu geschrieben. Gefunden: ${ID:-unbekannt}"; merke_mangel
  elif [[ "${VERSION_ID:-}" != "24.04" && "${VERSION_ID:-}" != "22.04" ]]; then
    warnung "Getestet gegen Ubuntu 24.04 LTS (und 22.04). Gefunden: ${VERSION_ID:-unbekannt} — vermutlich in Ordnung, aber ungeprüft."
  else
    ok "Ubuntu ${VERSION_ID} LTS"
  fi
else
  warnung "/etc/os-release nicht lesbar"; merke_mangel
fi

schritt "Prozessor, Arbeitsspeicher, Platte"
KERNE=$(nproc)
RAM_MB=$(awk '/MemTotal/ {printf "%d", $2/1024}' /proc/meminfo)
PLATTE_GB=$(df -BG --output=avail / | tail -1 | tr -dc '0-9')
echo "     Kerne: ${KERNE} · Arbeitsspeicher: ${RAM_MB} MB · frei auf /: ${PLATTE_GB} GB"
# Mindestwerte laut Supabase-Dokumentation (abgerufen 28.09.2026): 2 Kerne, 4 GB, 40 GB SSD.
(( KERNE >= 2 ))      || { fehler "Weniger als 2 Kerne. Supabase nennt 2 als Minimum."; merke_mangel; }
(( RAM_MB >= 3800 ))  || { fehler "Weniger als 4 GB Arbeitsspeicher. Supabase nennt 4 GB als Minimum."; merke_mangel; }
(( PLATTE_GB >= 40 )) || { fehler "Weniger als 40 GB frei. Supabase nennt 40 GB als Minimum."; merke_mangel; }
(( KERNE >= 4 ))      || warnung "2 Kerne reichen zum Starten, 4 sind für die Bildverarbeitung angenehmer."
(( RAM_MB >= 7600 ))  || warnung "4 GB reichen zum Starten, 8 GB sind für Prüfläufe angenehmer."

schritt "Auslagerungsspeicher (Swap)"
SWAP_MB=$(awk '/SwapTotal/ {printf "%d", $2/1024}' /proc/meminfo)
if (( SWAP_MB < 1024 )); then
  warnung "Nur ${SWAP_MB} MB Swap. Bei 4 GB Arbeitsspeicher kann ein Container beim Start abgeschossen werden."
  echo "     Abhilfe steht in 01-grundhaertung.sh (legt 2 GB Swap an)."
else
  ok "${SWAP_MB} MB Swap"
fi

schritt "Belegte Netzwerk-Anschlüsse"
for PORT in 80 443 8000 8443 5432; do
  if ss -ltn "sport = :${PORT}" 2>/dev/null | grep -q LISTEN; then
    warnung "Anschluss ${PORT} ist belegt:"
    ss -ltnp "sport = :${PORT}" 2>/dev/null | tail -n +2 | sed 's/^/       /'
    merke_mangel
  else
    ok "Anschluss ${PORT} frei"
  fi
done

schritt "Zeit und Zeitzone"
echo "     $(timedatectl show -p Timezone --value 2>/dev/null || echo unbekannt) · $(date -Is)"
if timedatectl show -p NTPSynchronized --value 2>/dev/null | grep -q yes; then
  ok "Uhr ist mit einem Zeitserver abgeglichen"
else
  warnung "Uhr ist nicht mit einem Zeitserver abgeglichen — Zertifikate und Protokolle leiden darunter."
fi

schritt "Netzverbindung nach außen"
for ZIEL in https://download.docker.com https://github.com https://registry-1.docker.io; do
  CODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 "$ZIEL" 2>/dev/null)" || true
  CODE="${CODE:-000}"
  case "$CODE" in
    2*|3*) ok "$ZIEL erreichbar (HTTP ${CODE})" ;;
    000)   fehler "$ZIEL NICHT erreichbar — keine Verbindung. Ohne diese Adresse schlägt die Einrichtung fehl."; merke_mangel ;;
    4*|5*) fehler "$ZIEL antwortet mit HTTP ${CODE} — meist ein Zwangsproxy oder eine Sperrliste dazwischen."; merke_mangel ;;
    *)     warnung "$ZIEL antwortet mit HTTP ${CODE} — unklar, bitte ansehen." ;;
  esac
done

schritt "Bereits vorhandene Teile"
command -v docker >/dev/null && ok "Docker ist schon da: $(docker --version)" || echo "     Docker fehlt noch (02-docker.sh legt es an)"
[[ -d "${CRUIZY_STACK}" ]] && warnung "${CRUIZY_STACK} existiert bereits — 03 würde nicht überschreiben, sondern abbrechen." || echo "     ${CRUIZY_STACK} existiert noch nicht"

schritt "Ergebnis"
if (( MANGEL == 0 )); then
  ok "Keine Hindernisse gefunden. Weiter mit 01-grundhaertung.sh"
  protokoll "Vorprüfung bestanden"
  exit 0
else
  fehler "${MANGEL} Punkt(e) müssen erst behoben werden. Oben rot markiert."
  protokoll "Vorprüfung mit ${MANGEL} Mängeln"
  exit 1
fi
