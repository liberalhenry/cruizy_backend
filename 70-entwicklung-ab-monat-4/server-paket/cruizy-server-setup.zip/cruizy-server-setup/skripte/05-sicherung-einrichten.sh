#!/usr/bin/env bash
# 05 · Sicherung einrichten: Skript an seinen Platz, Zeitplan, und eine
#      Probe-Rückspielung, die einmal wirklich durchläuft.
# Aufruf:  sudo bash skripte/05-sicherung-einrichten.sh
source "$(dirname "$0")/lib.sh"
braucht_root
PAKET="$(cd "$(dirname "$0")/.." && pwd)"
DIENSTNUTZER="${CRUIZY_NUTZER:-cruizy}"

schritt "Skripte an ihren Platz legen"
install -d -m 750 -o "$DIENSTNUTZER" -g "$DIENSTNUTZER" "${CRUIZY_BASIS}/sicherung" "${CRUIZY_BASIS}/sicherungen"
install -m 750 -o "$DIENSTNUTZER" -g "$DIENSTNUTZER" "$PAKET/sicherung/sichern.sh"        "${CRUIZY_BASIS}/sicherung/sichern.sh"
install -m 750 -o "$DIENSTNUTZER" -g "$DIENSTNUTZER" "$PAKET/sicherung/zurueckspielen.sh" "${CRUIZY_BASIS}/sicherung/zurueckspielen.sh"
ok "Liegen in ${CRUIZY_BASIS}/sicherung/"

schritt "Zeitplan über systemd"
cat > /etc/systemd/system/cruizy-sicherung.service <<CONF
[Unit]
Description=Cruizy — tägliche Sicherung von Datenbank und Konfiguration
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
User=${DIENSTNUTZER}
Environment=CRUIZY_BASIS=${CRUIZY_BASIS}
WorkingDirectory=${CRUIZY_STACK}
ExecStart=/bin/bash ${CRUIZY_BASIS}/sicherung/sichern.sh
CONF

# Zufällige Minute, damit nicht alles auf die volle Stunde fällt.
MINUTE=$(( RANDOM % 50 + 5 ))
cat > /etc/systemd/system/cruizy-sicherung.timer <<CONF
[Unit]
Description=Cruizy — Sicherung täglich

[Timer]
OnCalendar=*-*-* 03:$(printf '%02d' "$MINUTE"):00
Persistent=true
RandomizedDelaySec=300

[Install]
WantedBy=timers.target
CONF
systemctl daemon-reload
systemctl enable --now cruizy-sicherung.timer >/dev/null
ok "Läuft täglich um 03:$(printf '%02d' "$MINUTE") Uhr; verpasste Läufe werden nachgeholt"
systemctl list-timers cruizy-sicherung.timer --no-pager | sed 's/^/     /'

schritt "Erste Sicherung jetzt erzeugen"
sudo -u "$DIENSTNUTZER" env CRUIZY_BASIS="$CRUIZY_BASIS" bash "${CRUIZY_BASIS}/sicherung/sichern.sh" 2>&1 | sed 's/^/     /'

NEUESTE="$(ls -1t "${CRUIZY_BASIS}/sicherungen"/db_*.sql.gz 2>/dev/null | head -1 || true)"
[[ -n "$NEUESTE" ]] || abbruch "Es ist keine Sicherungsdatei entstanden."
ok "Neueste Sicherung: $(basename "$NEUESTE")"

schritt "Probe-Rückspielung — der Punkt, an dem sich Sicherungen bewähren"
echo "     Es wird in eine Wegwerf-Datenbank zurückgespielt. Die laufende bleibt unberührt."
if sudo -u "$DIENSTNUTZER" env CRUIZY_BASIS="$CRUIZY_BASIS" CRUIZY_PROBE=1 \
     bash "${CRUIZY_BASIS}/sicherung/zurueckspielen.sh" "$NEUESTE" 2>&1 | sed 's/^/     /'; then
  ok "Die Sicherung ist nachweislich zurückspielbar"
else
  abbruch "Die Probe-Rückspielung ist gescheitert. Eine Sicherung, die sich nicht
     zurückspielen lässt, ist keine. Vor der Abnahme klären."
fi

schritt "Was noch fehlt — ehrlich benannt"
cat <<TEXT
     Die Sicherungen liegen auf DEMSELBEN Server wie die Daten.
     Gegen einen Plattenfehler hilft das; gegen Verlust des Servers,
     ein versehentliches Löschen des ganzen Projekts oder eine Erpressung nicht.

     Nötig, bevor ein echter Mensch auf dem System ist:
       · eine zweite Kopie an einem anderen Ort (zweiter Server, Speicherbox, verschlüsselt)
       · Verschlüsselung der Sicherungen, wenn sie das Haus verlassen
     Beides steht in ANLEITUNG.md, Abschnitt 11, mit einem fertigen Vorschlag.
TEXT

protokoll "Sicherung eingerichtet, Probe-Rückspielung bestanden"
