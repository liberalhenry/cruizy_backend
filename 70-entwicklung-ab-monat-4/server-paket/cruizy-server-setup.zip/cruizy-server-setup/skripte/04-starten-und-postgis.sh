#!/usr/bin/env bash
# 04 · Stack starten, PostGIS einrichten, Rauchtest fahren.
# Läuft als Dienstnutzer.  Aufruf:  bash skripte/04-starten-und-postgis.sh
source "$(dirname "$0")/lib.sh"
braucht_kein_root
PAKET="$(cd "$(dirname "$0")/.." && pwd)"

[[ -d "$CRUIZY_STACK" ]] || abbruch "${CRUIZY_STACK} fehlt. Erst 03-supabase-holen.sh ausführen."
cd "$CRUIZY_STACK" || abbruch "Kann nicht nach ${CRUIZY_STACK} wechseln."
[[ -f .env ]] || abbruch ".env fehlt in ${CRUIZY_STACK}."

schritt "Pflichtwerte in .env prüfen"
FEHLT=0
for SCHLUESSEL in POSTGRES_PASSWORD SUPABASE_PUBLIC_URL API_EXTERNAL_URL SITE_URL; do
  WERT="$(grep -E "^${SCHLUESSEL}=" .env | head -1 | cut -d= -f2- || true)"
  if [[ -z "$WERT" ]]; then fehler "${SCHLUESSEL} ist leer oder fehlt"; FEHLT=$((FEHLT+1))
  else ok "${SCHLUESSEL} gesetzt"; fi
done
(( FEHLT == 0 )) || abbruch "${FEHLT} Pflichtwert(e) fehlen. ANLEITUNG.md, Abschnitt 6."

schritt "Abbilder holen"
docker compose pull 2>&1 | tail -5 | sed 's/^/     /'

schritt "Stack starten"
if [[ -f run.sh ]]; then sh run.sh start 2>&1 | tail -10 | sed 's/^/     /'
else docker compose up -d 2>&1 | tail -10 | sed 's/^/     /'; fi

schritt "Warten, bis die Datenbank antwortet"
BEREIT=0
for _ in $(seq 1 60); do
  if docker compose exec -T db pg_isready -U postgres >/dev/null 2>&1; then BEREIT=1; break; fi
  sleep 5
  printf '.'
done
echo
(( BEREIT == 1 )) || abbruch "Die Datenbank antwortet nach 5 Minuten nicht. Protokoll: docker compose logs db"
ok "Datenbank antwortet"

schritt "Zustand der Dienste"
docker compose ps --format 'table {{.Service}}\t{{.State}}\t{{.Status}}' 2>/dev/null | sed 's/^/     /' \
  || docker compose ps | sed 's/^/     /'
NICHT_OK="$(docker compose ps --status exited --status dead -q 2>/dev/null | wc -l)"
if [[ "$NICHT_OK" != "0" ]]; then
  warnung "${NICHT_OK} Dienst(e) laufen nicht. Ansehen mit: docker compose logs --tail=50"
fi

schritt "Postgres-Fassung"
PGF="$(docker compose exec -T db psql -U postgres -tAc 'SHOW server_version' 2>/dev/null | tr -d '\r' || echo unbekannt)"
echo "     ${PGF}"
case "$PGF" in
  17*) ok "PostgreSQL 17 — wie in der Spezifikation vorgesehen" ;;
  "")  warnung "Fassung nicht ermittelbar" ;;
  *)   warnung "Die Spezifikation nennt PostgreSQL 17, hier läuft ${PGF}."
       echo "     Kein Hindernis für den Bau, aber in der Abnahme vermerken." ;;
esac

schritt "PostGIS und Suchpfade einrichten"
docker compose exec -T db psql -U postgres -v ON_ERROR_STOP=1 < "$PAKET/sql/10-postgis.sql" 2>&1 \
  | grep -vE '^\s*$' | sed 's/^/     /'
ok "10-postgis.sql durchgelaufen"

schritt "Rauchtest — trägt geometry über die REST-Schnittstelle?"
echo "     Das ist die Prüfung, die den bekannten Fehler 27295 abfängt."
docker compose exec -T db psql -U postgres -v ON_ERROR_STOP=1 < "$PAKET/sql/20-rauchtest-aufbau.sql" >/dev/null 2>&1 \
  || abbruch "Der Aufbau des Rauchtests ist gescheitert — schon CREATE TABLE mit geometry geht nicht."
ok "Aufbau: Tabelle mit geometry-Spalte angelegt"

# 1 · Über die Datenbank, mit der Rolle, die PostgREST benutzt.
ERGEBNIS="$(docker compose exec -T db psql -U postgres -qtA \
  -c "SET ROLE anon;" \
  -c "SELECT ort_id||'|'||round(entfernung_m) FROM public.cruizy_rauchtest_umkreis(50.9375,6.9603,1000);" \
  2>&1 | tr -d '\r' | grep -E '^[0-9]+\|' || true)"
if [[ "$ERGEBNIS" == "1|0" ]]; then
  ok "Rolle anon kann geometry auflösen und rechnen (${ERGEBNIS})"
else
  fehler "Rolle anon kann geometry NICHT auflösen. Ausgabe: ${ERGEBNIS:-leer}"
  echo "     Das ist genau Fehler 27295. Abhilfe steht in ANLEITUNG.md, Abschnitt 9."
  docker compose exec -T db psql -U postgres -v ON_ERROR_STOP=1 < "$PAKET/sql/21-rauchtest-abbau.sql" >/dev/null 2>&1 || true
  abbruch "Rauchtest gescheitert — nicht weitermachen, bevor das steht."
fi

# 2 · Über die REST-Schnittstelle, also über den echten Weg.
ANON_KEY="$(grep -E '^(ANON_KEY|SUPABASE_PUBLISHABLE_KEY)=' .env | head -1 | cut -d= -f2- | tr -d '"' || true)"
if [[ -n "$ANON_KEY" ]]; then
  ANTWORT="$(curl -fsS --max-time 20 \
      -X POST "http://127.0.0.1:8000/rest/v1/rpc/cruizy_rauchtest_umkreis" \
      -H "apikey: ${ANON_KEY}" -H "Authorization: Bearer ${ANON_KEY}" \
      -H "Content-Type: application/json" \
      -d '{"breite":50.9375,"laenge":6.9603,"meter":1000}' 2>&1 || echo "FEHLER")"
  if [[ "$ANTWORT" == *'"ort_id":1'* || "$ANTWORT" == *'"ort_id": 1'* ]]; then
    ok "REST-Schnittstelle liefert das Ergebnis: ${ANTWORT}"
  else
    warnung "Über REST kam keine verwertbare Antwort: ${ANTWORT}"
    echo "     Der Datenbankteil ist in Ordnung. Prüfe das Tor: docker compose logs --tail=50"
  fi
else
  warnung "Kein anon-Schlüssel in .env gefunden — REST-Teil des Rauchtests übersprungen."
fi

docker compose exec -T db psql -U postgres -v ON_ERROR_STOP=1 < "$PAKET/sql/21-rauchtest-abbau.sql" >/dev/null 2>&1
ok "Rauchtest-Reste entfernt"

schritt "Erreichbarkeit von außen — Gegenprobe"
OEFFENTLICH="$(docker compose ps --format json 2>/dev/null | grep -o '0\.0\.0\.0:[0-9]*' | sort -u || true)"
if [[ -n "$OEFFENTLICH" ]]; then
  fehler "Diese Anschlüsse sind nach außen offen:"; echo "$OEFFENTLICH" | sed 's/^/       /'
  echo "     Erwartet war: keine. Prüfe docker-compose.override.yml."
else
  ok "Kein Anschluss ist nach außen offen — Zugriff nur über SSH-Tunnel"
fi

protokoll "Stack gestartet, PostGIS eingerichtet, Rauchtest bestanden"
schritt "Fertig"
cat <<TEXT
     So kommst du an die Oberfläche (von deinem Rechner aus, nicht auf dem Server):
       ssh -L 8000:127.0.0.1:8000 ${USER}@<server-ip>
     Danach im Browser:  http://127.0.0.1:8000
     Zugangsdaten: DASHBOARD_USERNAME und DASHBOARD_PASSWORD aus .env

     Weiter mit:  sudo bash skripte/05-sicherung-einrichten.sh
TEXT
