#!/usr/bin/env bash
# 03 · Supabase holen, Geheimnisse erzeugen, Anschlüsse zunageln.
# Läuft als Dienstnutzer, NICHT als root.
# Aufruf:  bash skripte/03-supabase-holen.sh
source "$(dirname "$0")/lib.sh"
braucht_kein_root
PAKET="$(cd "$(dirname "$0")/.." && pwd)"

# Fassung des offiziellen Supabase-Selbstbetriebszweigs. Siehe ANLEITUNG.md, Abschnitt „Fassungen".
ZWEIG="${CRUIZY_SUPABASE_ZWEIG:-self-hosted/v0.8.2}"

command -v docker >/dev/null || abbruch "Docker fehlt. Erst 02-docker.sh ausführen."
docker info >/dev/null 2>&1 || abbruch "Docker ist nicht bedienbar. Nach 02 einmal ab- und wieder anmelden."
[[ -w "$CRUIZY_BASIS" ]] || abbruch "${CRUIZY_BASIS} ist nicht beschreibbar. Lief 01-grundhaertung.sh durch?"

if [[ -d "$CRUIZY_STACK" ]]; then
  abbruch "${CRUIZY_STACK} existiert bereits. Dieses Skript überschreibt nichts.
     Wenn du neu anfangen willst, sichere das Verzeichnis und benenne es um."
fi

schritt "Offizielles Supabase holen (Zweig ${ZWEIG})"
ARBEIT="$(mktemp -d)"
trap 'rm -rf "$ARBEIT"' EXIT
git clone --depth 1 --branch "$ZWEIG" https://github.com/supabase/supabase "$ARBEIT/supabase" 2>&1 | sed 's/^/     /'
FESTSTAND="$(git -C "$ARBEIT/supabase" rev-parse HEAD)"
ok "Geholt, Stand ${FESTSTAND}"

mkdir -p "$CRUIZY_STACK"
cp -rf "$ARBEIT/supabase/docker/." "$CRUIZY_STACK/"
[[ -f "$CRUIZY_STACK/docker-compose.yml" ]] || abbruch "Im geholten Zweig liegt keine docker-compose.yml. Zweigname prüfen."
ok "Nach ${CRUIZY_STACK} kopiert"

# Genau festhalten, was installiert wurde — sonst ist später nicht nachvollziehbar,
# gegen welchen Stand gebaut wurde.
cat > "$CRUIZY_BASIS/HERKUNFT.txt" <<HERKUNFT
Supabase, selbst gehostet — Herkunft dieser Installation
Geholt am        : $(date -Is)
Quelle           : https://github.com/supabase/supabase
Zweig            : ${ZWEIG}
Feststand        : ${FESTSTAND}
Eingerichtet von : $(whoami)@$(hostname)
Paketfassung     : $(cat "$PAKET/FASSUNG.txt" 2>/dev/null || echo unbekannt)
HERKUNFT
ok "Herkunft festgehalten in ${CRUIZY_BASIS}/HERKUNFT.txt"

schritt "Geheimnisse erzeugen"
cd "$CRUIZY_STACK" || abbruch "Kann nicht nach ${CRUIZY_STACK} wechseln."
[[ -f .env ]] || { [[ -f .env.example ]] && cp .env.example .env && ok ".env aus .env.example angelegt"; }
ERZEUGT=0
for WERKZEUG in utils/generate-keys.sh utils/add-new-auth-keys.sh; do
  if [[ -f "$WERKZEUG" ]]; then
    schritt "  ${WERKZEUG}"
    sh "$WERKZEUG" 2>&1 | sed 's/^/     /'
    ERZEUGT=$((ERZEUGT+1))
  fi
done
if (( ERZEUGT == 0 )); then
  warnung "Die offiziellen Schlüsselskripte liegen in diesem Zweig nicht unter utils/."
  echo "     Trage die Geheimnisse in .env von Hand ein. ANLEITUNG.md, Abschnitt 6 sagt welche."
else
  ok "${ERZEUGT} Schlüsselskript(e) gelaufen"
fi

schritt "Prüfen, dass keine Beispielgeheimnisse stehen geblieben sind"
VERDAECHTIG=0
while IFS= read -r ZEILE; do
  warnung "Verdächtiger Wert: ${ZEILE%%=*}"
  VERDAECHTIG=$((VERDAECHTIG+1))
done < <(grep -nE '=(your-super-secret|this_password_is_insecure|super-secret-jwt-token|example|changeme|password)' .env 2>/dev/null || true)
if (( VERDAECHTIG > 0 )); then
  fehler "${VERDAECHTIG} Wert(e) sehen nach Beispieldaten aus. Vor dem Start ersetzen."
  echo "     Sonst ist die Installation mit veröffentlichten Standardgeheimnissen erreichbar."
else
  ok "Keine offensichtlichen Beispielgeheimnisse in .env"
fi
chmod 600 .env
ok ".env auf 600 gesetzt (nur ${USER} darf lesen)"

schritt "Anschlüsse an 127.0.0.1 binden"
if docker compose config --format json > "$ARBEIT/konfig.json" 2>"$ARBEIT/konfig.err"; then
  python3 "$PAKET/skripte/bindung.py" < "$ARBEIT/konfig.json" > docker-compose.override.yml
  ok "docker-compose.override.yml geschrieben"
  echo "     Damit ist nichts aus dem Internet erreichbar — Zugriff nur über SSH-Tunnel."
else
  sed 's/^/     /' "$ARBEIT/konfig.err"
  abbruch "docker compose config ist fehlgeschlagen. Meist fehlt ein Wert in .env."
fi

schritt "Was jetzt in ${CRUIZY_STACK} liegt"
ls -1 | sed 's/^/     /'

protokoll "Supabase geholt: ${ZWEIG} ${FESTSTAND}"
schritt "Fertig"
cat <<TEXT
     NOCH NICHT GESTARTET. Vorher drei Werte in .env setzen — ANLEITUNG.md, Abschnitt 6:
       SUPABASE_PUBLIC_URL · API_EXTERNAL_URL · SITE_URL   (vorläufig http://127.0.0.1:8000)
       DASHBOARD_USERNAME und DASHBOARD_PASSWORD

     Danach:   bash skripte/04-starten-und-postgis.sh
TEXT
