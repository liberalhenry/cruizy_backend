#!/usr/bin/env python3
"""Erzeugt eine docker-compose.override.yml, die JEDEN nach außen veröffentlichten
Anschluss auf 127.0.0.1 zurückbindet.

Warum das nötig ist: Docker schreibt seine Weiterleitungsregeln unterhalb von ufw in
die Firewall. Ein Container, der 0.0.0.0:8000 öffnet, ist damit aus dem Internet
erreichbar, obwohl `ufw status` „deny incoming" meldet. Das ist kein Fehler von ufw,
sondern die dokumentierte Arbeitsweise von Docker — und die häufigste Ursache dafür,
dass eine Datenbank ungewollt offen im Netz steht.

Aufruf:  docker compose config --format json | python3 bindung.py > docker-compose.override.yml
Ausgabe auf stderr: Was gefunden und was umgebogen wurde.
"""
import json
import sys

ERLAUBT_OEFFENTLICH = set()  # bewusst leer: nichts geht ohne ausdrückliche Änderung nach außen


def main() -> int:
    try:
        konfig = json.load(sys.stdin)
    except json.JSONDecodeError as fehler:
        print(f"Konnte die Compose-Konfiguration nicht lesen: {fehler}", file=sys.stderr)
        return 2

    dienste = konfig.get("services") or {}
    if not dienste:
        print("Keine Dienste in der Compose-Konfiguration gefunden.", file=sys.stderr)
        return 2

    ueberschreibung: dict[str, dict] = {}
    gefunden = 0
    for name, dienst in sorted(dienste.items()):
        anschluesse = dienst.get("ports") or []
        neue = []
        geaendert = False
        for eintrag in anschluesse:
            # Compose gibt im JSON-Format immer die lange Schreibweise aus.
            if isinstance(eintrag, dict):
                veroeffentlicht = eintrag.get("published")
                ziel = eintrag.get("target")
                bisher = eintrag.get("host_ip") or "0.0.0.0"
                protokoll = eintrag.get("protocol") or "tcp"
            else:  # kurze Schreibweise, z. B. "8000:8000"
                teile = str(eintrag).split(":")
                bisher = teile[0] if len(teile) == 3 else "0.0.0.0"
                veroeffentlicht = teile[-2] if len(teile) >= 2 else None
                ziel = teile[-1]
                protokoll = "tcp"
            if veroeffentlicht is None or ziel is None:
                continue
            gefunden += 1
            offen = bisher in ("", "0.0.0.0", "::")
            if offen and str(veroeffentlicht) not in ERLAUBT_OEFFENTLICH:
                geaendert = True
                print(f"  umgebogen: {name} {bisher}:{veroeffentlicht} -> 127.0.0.1:{veroeffentlicht}", file=sys.stderr)
            else:
                print(f"  belassen : {name} {bisher}:{veroeffentlicht}", file=sys.stderr)
            neue.append(f"127.0.0.1:{veroeffentlicht}:{ziel}" + ("/udp" if protokoll == "udp" else ""))
        if geaendert:
            ueberschreibung[name] = {"ports": neue}

    kopf = (
        "# Von bindung.py erzeugt — NICHT von Hand bearbeiten.\n"
        "# Bindet jeden veroeffentlichten Anschluss an 127.0.0.1, damit Docker\n"
        "# die Firewall nicht unterlaeuft. Zugriff von aussen ausschliesslich\n"
        "# ueber einen SSH-Tunnel oder einen vorgeschalteten Reverse-Proxy.\n"
    )
    if not ueberschreibung:
        print(kopf + "services: {}\n", end="")
        print(f"Nichts umzubiegen ({gefunden} Anschluss/Anschlüsse geprüft).", file=sys.stderr)
        return 0

    zeilen = [kopf, "services:"]
    for name, inhalt in ueberschreibung.items():
        zeilen.append(f"  {name}:")
        zeilen.append("    ports:")
        for p in inhalt["ports"]:
            zeilen.append(f'      - "{p}"')
    print("\n".join(zeilen) + "\n", end="")
    print(f"{len(ueberschreibung)} Dienst(e) umgebogen, {gefunden} Anschluss/Anschlüsse geprüft.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
