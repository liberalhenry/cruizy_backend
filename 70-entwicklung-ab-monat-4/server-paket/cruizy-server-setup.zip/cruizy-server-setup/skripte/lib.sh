#!/usr/bin/env bash
# Gemeinsame Funktionen für alle Cruizy-Einrichtungsskripte.
# Wird von den nummerierten Skripten eingebunden, nicht einzeln aufgerufen.

set -euo pipefail

FARBE_ROT=$'\033[31m'; FARBE_GRUEN=$'\033[32m'; FARBE_GELB=$'\033[33m'
FARBE_BLAU=$'\033[34m'; FARBE_AUS=$'\033[0m'

schritt()  { printf '\n%s▸ %s%s\n' "$FARBE_BLAU" "$*" "$FARBE_AUS"; }
ok()       { printf '%s  ✔ %s%s\n' "$FARBE_GRUEN" "$*" "$FARBE_AUS"; }
warnung()  { printf '%s  ! %s%s\n' "$FARBE_GELB" "$*" "$FARBE_AUS"; }
fehler()   { printf '%s  ✖ %s%s\n' "$FARBE_ROT" "$*" "$FARBE_AUS" >&2; }
abbruch()  { fehler "$*"; exit 1; }

# frage "Text" -> 0 bei ja, 1 bei nein. Bei CRUIZY_JA=1 immer ja (für unbeaufsichtigte Läufe).
frage() {
  if [[ "${CRUIZY_JA:-0}" == "1" ]]; then return 0; fi
  local antwort
  read -r -p "  $1 [j/N] " antwort
  [[ "$antwort" =~ ^([jJ]|[yY])$ ]]
}

braucht_root() {
  [[ "${EUID}" -eq 0 ]] || abbruch "Dieses Skript muss mit sudo laufen: sudo bash $0"
}

braucht_kein_root() {
  [[ "${EUID}" -ne 0 ]] || abbruch "Dieses Skript darf NICHT als root laufen. Melde dich als Dienstnutzer an."
}

# Schreibt eine Zeile in das Protokoll aller Einrichtungsschritte.
PROTOKOLL="${CRUIZY_PROTOKOLL:-/var/log/cruizy-einrichtung.log}"
protokoll() {
  local zeile
  zeile="$(date -Is) | $(basename "${0}") | $*"
  if [[ -w "$(dirname "$PROTOKOLL")" ]] || [[ -w "$PROTOKOLL" ]] 2>/dev/null; then
    printf '%s\n' "$zeile" >> "$PROTOKOLL" 2>/dev/null || true
  fi
}

# Verzeichnis, in dem der Supabase-Stack liegt. Von allen Skripten gemeinsam genutzt.
CRUIZY_BASIS="${CRUIZY_BASIS:-/opt/cruizy}"
CRUIZY_STACK="${CRUIZY_STACK:-${CRUIZY_BASIS}/supabase}"
