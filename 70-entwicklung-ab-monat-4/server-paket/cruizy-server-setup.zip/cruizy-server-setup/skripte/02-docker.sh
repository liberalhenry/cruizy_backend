#!/usr/bin/env bash
# 02 · Docker und Docker Compose aus der offiziellen Paketquelle.
# Aufruf:  sudo bash skripte/02-docker.sh
source "$(dirname "$0")/lib.sh"
braucht_root

DIENSTNUTZER="${CRUIZY_NUTZER:-cruizy}"

if command -v docker >/dev/null && docker compose version >/dev/null 2>&1; then
  ok "Docker und Compose sind bereits vorhanden: $(docker --version)"
else
  schritt "Offizielle Docker-Paketquelle eintragen"
  export DEBIAN_FRONTEND=noninteractive
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -qq
  ok "Paketquelle eingetragen"

  schritt "Docker installieren"
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >/dev/null
  ok "$(docker --version)"
  ok "$(docker compose version)"
fi

schritt "Protokolle begrenzen"
# Ohne diese Begrenzung füllen Container-Protokolle langsam die Platte.
install -d -m 755 /etc/docker
if [[ -s /etc/docker/daemon.json ]] && ! jq -e '."log-opts"."max-size"' /etc/docker/daemon.json >/dev/null 2>&1; then
  cp /etc/docker/daemon.json "/etc/docker/daemon.json.vor-cruizy.$(date +%Y%m%d%H%M%S)"
  jq '. + {"log-driver":"json-file","log-opts":{"max-size":"20m","max-file":"5"},"live-restore":true}' \
     /etc/docker/daemon.json > /etc/docker/daemon.json.neu && mv /etc/docker/daemon.json.neu /etc/docker/daemon.json
  ok "Vorhandene daemon.json ergänzt (Sicherungskopie daneben)"
elif [[ ! -s /etc/docker/daemon.json ]]; then
  cat > /etc/docker/daemon.json <<'CONF'
{
  "log-driver": "json-file",
  "log-opts": { "max-size": "20m", "max-file": "5" },
  "live-restore": true
}
CONF
  ok "daemon.json angelegt: je Container höchstens 5 × 20 MB Protokoll"
else
  ok "Protokollbegrenzung ist bereits gesetzt"
fi

systemctl enable --now docker >/dev/null
systemctl restart docker
ok "Docker läuft und startet beim Hochfahren mit"

schritt "Dienstnutzer in die Gruppe docker"
usermod -aG docker "$DIENSTNUTZER"
ok "${DIENSTNUTZER} darf Docker bedienen"
warnung "Die Gruppenzugehörigkeit greift erst nach einer neuen Anmeldung."
echo "     Melde dich einmal ab und wieder an, bevor du 03 aufrufst."

schritt "Kurzer Funktionstest"
if docker run --rm hello-world >/dev/null 2>&1; then
  ok "Docker kann Abbilder holen und Container starten"
else
  abbruch "Der Funktionstest ist fehlgeschlagen. Prüfe: systemctl status docker"
fi

protokoll "Docker eingerichtet: $(docker --version)"
schritt "Fertig"
echo "     Abmelden, neu anmelden, dann:  bash skripte/03-supabase-holen.sh"
