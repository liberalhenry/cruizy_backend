#!/usr/bin/env bash
# 01 · Grundhärtung des frischen Servers.
# Legt den Dienstnutzer an, härtet SSH, richtet Firewall, fail2ban,
# automatische Sicherheitsaktualisierungen, Zeitzone und Swap ein.
# Aufruf:  sudo bash skripte/01-grundhaertung.sh
source "$(dirname "$0")/lib.sh"
braucht_root

DIENSTNUTZER="${CRUIZY_NUTZER:-cruizy}"
SSH_PORT="${CRUIZY_SSH_PORT:-22}"

schritt "Zusammenfassung dessen, was gleich geschieht"
cat <<TEXT
     Nutzer         : ${DIENSTNUTZER} (wird angelegt, falls nicht vorhanden, mit sudo-Recht)
     SSH            : Anmeldung als root aus, Passwortanmeldung aus, nur Schlüssel
     SSH-Anschluss  : ${SSH_PORT}
     Firewall (ufw) : alles zu, außer SSH
     fail2ban       : an, für SSH
     Aktualisierung : Sicherheitsaktualisierungen automatisch
     Zeitzone       : Europe/Berlin
     Swap           : 2 GB, falls weniger als 1 GB vorhanden

     ⚠ Sperr dich nicht aus: Bevor die Passwortanmeldung abgeschaltet wird,
       muss dein öffentlicher SSH-Schlüssel in ~${DIENSTNUTZER}/.ssh/authorized_keys liegen.
TEXT
frage "Fortfahren?" || abbruch "Abgebrochen. Nichts geändert."

schritt "Paketquellen auffrischen und Grundwerkzeuge nachziehen"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq ca-certificates curl gnupg ufw fail2ban unattended-upgrades \
                      apt-listchanges jq git zip unzip htop ncdu postgresql-client >/dev/null
ok "Grundwerkzeuge vorhanden"

schritt "Zeitzone"
timedatectl set-timezone Europe/Berlin
ok "$(timedatectl show -p Timezone --value)"

schritt "Dienstnutzer ${DIENSTNUTZER}"
if id "$DIENSTNUTZER" >/dev/null 2>&1; then
  ok "Nutzer existiert bereits"
else
  adduser --disabled-password --gecos "Cruizy Dienstnutzer" "$DIENSTNUTZER" >/dev/null
  ok "Nutzer angelegt (ohne Passwort — Anmeldung nur per Schlüssel)"
fi
usermod -aG sudo "$DIENSTNUTZER"
install -d -m 700 -o "$DIENSTNUTZER" -g "$DIENSTNUTZER" "/home/${DIENSTNUTZER}/.ssh"

# Schlüssel von root übernehmen, damit niemand ausgesperrt wird.
if [[ -s /root/.ssh/authorized_keys && ! -s "/home/${DIENSTNUTZER}/.ssh/authorized_keys" ]]; then
  cp /root/.ssh/authorized_keys "/home/${DIENSTNUTZER}/.ssh/authorized_keys"
  chown "${DIENSTNUTZER}:${DIENSTNUTZER}" "/home/${DIENSTNUTZER}/.ssh/authorized_keys"
  chmod 600 "/home/${DIENSTNUTZER}/.ssh/authorized_keys"
  ok "SSH-Schlüssel von root übernommen"
fi

if [[ ! -s "/home/${DIENSTNUTZER}/.ssh/authorized_keys" ]]; then
  fehler "Für ${DIENSTNUTZER} liegt kein SSH-Schlüssel vor."
  echo "     Lege ihn von deinem Rechner aus an:"
  echo "       ssh-copy-id -p ${SSH_PORT} ${DIENSTNUTZER}@<server-ip>"
  echo "     Danach dieses Skript erneut aufrufen."
  abbruch "SSH-Härtung wird nicht durchgeführt, solange kein Schlüssel hinterlegt ist."
fi
ok "SSH-Schlüssel liegt vor ($(wc -l < "/home/${DIENSTNUTZER}/.ssh/authorized_keys") Zeile(n))"

schritt "SSH härten"
install -d -m 755 /etc/ssh/sshd_config.d
cat > /etc/ssh/sshd_config.d/10-cruizy.conf <<CONF
# Von 01-grundhaertung.sh geschrieben. Änderungen hier, nicht in sshd_config.
Port ${SSH_PORT}
PermitRootLogin no
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
X11Forwarding no
MaxAuthTries 3
LoginGraceTime 30
AllowUsers ${DIENSTNUTZER}
CONF
if sshd -t; then
  systemctl reload ssh 2>/dev/null || systemctl reload sshd
  ok "SSH neu geladen — Passwortanmeldung aus, root aus, nur ${DIENSTNUTZER}"
  warnung "Lass diese Sitzung offen und prüfe in einem ZWEITEN Fenster, dass du dich anmelden kannst."
else
  rm -f /etc/ssh/sshd_config.d/10-cruizy.conf
  abbruch "Die SSH-Konfiguration war fehlerhaft und wurde zurückgenommen. Nichts geändert."
fi

schritt "Firewall (ufw)"
ufw --force reset >/dev/null
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow "${SSH_PORT}/tcp" comment 'SSH' >/dev/null
ufw --force enable >/dev/null
ufw status verbose | sed 's/^/     /'
warnung "Wichtig: Docker umgeht ufw, wenn ein Container einen Anschluss nach außen öffnet."
echo "     Deshalb bindet 03-supabase-holen.sh alle Anschlüsse ausdrücklich an 127.0.0.1."

schritt "fail2ban"
cat > /etc/fail2ban/jail.d/cruizy.conf <<CONF
[sshd]
enabled  = true
port     = ${SSH_PORT}
backend  = systemd
maxretry = 3
findtime = 10m
bantime  = 1h
CONF
systemctl enable --now fail2ban >/dev/null 2>&1 || true
systemctl restart fail2ban
ok "fail2ban läuft"

schritt "Automatische Sicherheitsaktualisierungen"
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'CONF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
CONF
cat > /etc/apt/apt.conf.d/51cruizy-unattended <<'CONF'
Unattended-Upgrade::Automatic-Reboot "false";
Unattended-Upgrade::Remove-Unused-Kernel-Packages "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
CONF
systemctl enable --now unattended-upgrades >/dev/null 2>&1 || true
ok "Sicherheitsaktualisierungen laufen automatisch, Neustart aber NICHT automatisch"
warnung "Neustarts bleiben eure Entscheidung. 'cat /var/run/reboot-required' zeigt, ob einer ansteht."

schritt "Auslagerungsspeicher"
SWAP_MB=$(awk '/SwapTotal/ {printf "%d", $2/1024}' /proc/meminfo)
if (( SWAP_MB < 1024 )); then
  if [[ -e /swapfile ]]; then
    warnung "/swapfile existiert bereits, wird nicht angefasst"
  else
    fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none
    chmod 600 /swapfile; mkswap /swapfile >/dev/null; swapon /swapfile
    grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
    sysctl -q -w vm.swappiness=10
    grep -q '^vm.swappiness' /etc/sysctl.conf || echo 'vm.swappiness=10' >> /etc/sysctl.conf
    ok "2 GB Swap angelegt"
  fi
else
  ok "${SWAP_MB} MB Swap vorhanden"
fi

schritt "Arbeitsverzeichnis"
install -d -m 750 -o "$DIENSTNUTZER" -g "$DIENSTNUTZER" "$CRUIZY_BASIS"
ok "${CRUIZY_BASIS} gehört ${DIENSTNUTZER}"

protokoll "Grundhärtung abgeschlossen für ${DIENSTNUTZER}, SSH-Port ${SSH_PORT}"
schritt "Fertig"
cat <<TEXT
     Prüfe JETZT in einem zweiten Fenster:
       ssh -p ${SSH_PORT} ${DIENSTNUTZER}@<server-ip>
     Erst wenn das klappt, diese Sitzung schließen.

     Danach weiter mit:  sudo bash skripte/02-docker.sh
TEXT
